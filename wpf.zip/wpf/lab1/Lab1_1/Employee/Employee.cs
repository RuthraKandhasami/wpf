﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLib
{
    public abstract class Employee
    {
        public int employeeid;
        public string employeename;
        public string address;
        public string city;
        public string department;
        public int salary;

        public int Employeeid {
            get {
                return employeeid; 
                }
            set {
                employeeid = value; 
                }
        }

        public string Employeename
        {
            get
            {
                return employeename;
            }
            set
            {
                employeename = value;
            }
        }

        public string Address
        {
            get
            {
                return address;
            }
            set
            {
                address = value;
            }
        }

        public string City
        {
            get
            {
                return city;
            }
            set
            {
                city = value;
            }
        }

        public string Department
        {
            get
            {
                return department;
            }
            set
            {
                department = value;
            }
        }

        public int Salary
        {
            get
            {
                return salary;
            }
            set
            {
                salary = value;
            }
        }

        public abstract int GetSalary();
    
            
       
   

    }
}
