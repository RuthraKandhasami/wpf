﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB2_Q4
{
    class ProductDemo
    {
        static void Main(string[] args)
        {
            object objProductID, objProductName , objPrice, objQuantity;
            double AmountPayable;

            Console.Write("Enter the id of product : ");
            objProductID = Console.ReadLine();
            Console.Write("\nEnter the name of product : ");
            objProductName = Console.ReadLine();
            Console.Write("\nEnter price : ");
            objPrice = Console.ReadLine();
            Console.Write("\nEnter quantity : ");
            objQuantity = Console.ReadLine();
            //unboxing
            int ProductID = Convert.ToInt32(objProductID);
            int Quantity = Convert.ToInt32(objQuantity);
            int Price= Convert.ToInt32(objPrice);
            //
            AmountPayable = Quantity * Price;
            //
            Console.WriteLine("\n\n---------- Product Details ------- ");
            Console.WriteLine("Product ID : "+ ProductID);
            Console.WriteLine("Product Name : "+objProductName.ToString());
            Console.WriteLine("Price : " + Price);
            Console.WriteLine("Quantity : " + Quantity);
            Console.WriteLine("Amt Payable : " + AmountPayable);

        }
    }
}
