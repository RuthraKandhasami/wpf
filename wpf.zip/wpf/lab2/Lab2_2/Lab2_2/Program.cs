﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_2
{
    class Program
    {
        static int[,] twoDarray = new int[2, 2];
        static void Main(string[] args)
        {
            AcceptData();

            Displaydetails();

            Console.ReadKey();
        }

        static void AcceptData()
        {
            Console.WriteLine("----getting values from user----");
            for (int i = 0; i < twoDarray.GetLength(0); i++)
            {            
                Console.WriteLine("values for Row :" + i);
            for (int j = 0; j < twoDarray.GetLength(1); j++)
                { 
                Console.WriteLine("values for column :" + j);
                    twoDarray[i, j] = Convert.ToInt32(Console.ReadLine());
        }
    }
}
    static void Displaydetails()
    {
        Console.WriteLine("----Displaying numbers in array format---");
        for (int i = 0; i < twoDarray.GetLength(0); i++)
        {
            for (int j = 0; j < twoDarray.GetLength(1); j++)
        { 
            Console.Write(twoDarray[i, j] + " ");
        }
        Console.WriteLine();
        }
       }        
      }
   }

        
    

