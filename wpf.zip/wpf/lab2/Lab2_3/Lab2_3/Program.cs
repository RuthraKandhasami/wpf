﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2_3
{
    class Program
    {
        static string[] citynames = new string[4];
        static void Main(string[] args)
        {
            GetCitynames();
            Displaynames();
            Console.ReadKey();

        }

        static void GetCitynames()
        {
            Console.WriteLine("-----Getting the names of the cities---");
            Console.WriteLine("Enter the city names ");
            for (int i = 0; i < citynames.Length; i++)
                citynames[i] = Convert.ToString(Console.ReadLine());


        }

        static void Displaynames()
        {
            Console.WriteLine("---display city names---");
            foreach (string city in citynames)
            {
                Console.WriteLine(city);
            }
        }
    }
}

